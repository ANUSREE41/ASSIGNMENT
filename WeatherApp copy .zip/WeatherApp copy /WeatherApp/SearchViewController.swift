//
//  SearchViewController.swift
//  WeatherApp
//
//  Created by Anusree K Babu on 11/06/21.
//

import UIKit

class SearchViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        tableView.delegate = self
        tableView.dataSource = self
        
    }

    @IBAction func backButtonClicked(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if let searchViewCell = tableView.dequeueReusableCell(withIdentifier: "searchViewCell", for: indexPath) as? SearchViewCell {
            
            searchViewCell.cityName.text = "ksd"
            return searchViewCell
        }
        return SearchViewCell()
    }
    
    
}
