//
//  UIImage+Extension.swift
//  WeatherApp
//
//  Created by Anusree K Babu on 09/06/21.
//

import UIKit

extension UIImage {
    
    static func viewBackgroundImage() -> UIImage? {
        
        return UIImage(named: "background_android") ?? nil
    }
}
