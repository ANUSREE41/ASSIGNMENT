//
//  BackgroundImageView.swift
//  WeatherApp
//
//  Created by Anusree K Babu on 09/06/21.
//

import UIKit

class BackgroundSettingsView: UIView {
    
    override init(frame: CGRect) {
        
        super.init(frame: frame)
        self.insertBackgroundImage()
//        self.setStatusBarBackground()
    }
    
    required init?(coder: NSCoder) {
        
        super.init(coder: coder)
        self.insertBackgroundImage()
//        self.setStatusBarBackground()
    }
    var backgroundImage = UIImageView()
    
    func insertBackgroundImage() {
        
        backgroundImage = UIImageView(frame: UIScreen.main.bounds)
        backgroundImage.image = UIImage.viewBackgroundImage()
        self.insertSubview(backgroundImage, at: 0)
    }
    
//    func setStatusBarBackground() {
//
//        let statusBarView = UIView(frame: UIApplication.shared.statusBarFrame)
//        let statusBarColor = UIColor.statusBarColor()
//        statusBarView.backgroundColor = statusBarColor
//        self.addSubview(statusBarView)
//    }
    
    
}
