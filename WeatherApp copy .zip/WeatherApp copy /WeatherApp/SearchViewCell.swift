//
//  SearchViewCell.swift
//  WeatherApp
//
//  Created by Anusree K Babu on 11/06/21.
//

import UIKit

class SearchViewCell: UITableViewCell {
    
    @IBOutlet weak var cityName: UILabel!
    
}
