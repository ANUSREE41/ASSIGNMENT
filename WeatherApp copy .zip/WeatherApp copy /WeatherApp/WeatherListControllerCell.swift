//
//  WeatherListControllerCell.swift
//  WeatherApp
//
//  Created by Anusree K Babu on 10/06/21.
//

import UIKit

class WeatherListControllerCell: UITableViewCell {
    
    @IBOutlet weak var place: UILabel!
    @IBOutlet weak var weatherImage: UIImageView!
    @IBOutlet weak var temperature: RobotoMediumFontWithSize18Label!
    @IBOutlet weak var temperatureStatus: UILabel!
    
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        contentView.frame = contentView.frame.inset(by: UIEdgeInsets(top: 0, left: 0, bottom: 2, right: 0))
    }
}
