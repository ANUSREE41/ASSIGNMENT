//
//  homeScreenViewModel.swift
//  WeatherApp
//
//  Created by Anusree K Babu on 11/06/21.
//

import Foundation

class HomeScreenViewModel {
    
    let networkManager = NetworkManager()
    var weatherData = [WeatherData]()
    
    func fetchWeatherDetails() {
        networkManager.fetchWeatherData()
    }
}
