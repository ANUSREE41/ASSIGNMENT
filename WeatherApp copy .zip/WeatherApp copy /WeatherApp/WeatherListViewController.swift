//
//  WeatherListViewController.swift
//  WeatherApp
//
//  Created by Anusree K Babu on 10/06/21.
//

import UIKit

enum RequiredList: String {
    
    case favouriteList
    case recentSearchList
}

class WeatherListViewController: UIViewController {
    
    @IBOutlet weak var emptyView: UIView!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var listView: UIView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var leftViewLabel: RobotoRegularFontWithSize13Label!
    @IBOutlet weak var rightViewButton: UIButton!    
    @IBOutlet weak var emptyViewLabel: UILabel!
    
    
    var requiredList = RequiredList.favouriteList
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        tableView.delegate = self
        tableView.dataSource = self
        self.tableView.rowHeight = 85
        emptyView.isHidden = true
        listView.isHidden = false
        
        if(requiredList == .favouriteList) {
            titleLabel.text = "Favourite"
            leftViewLabel.text = "6 city added as favourite"
            rightViewButton.setTitle("Remove All", for: .normal)
            emptyViewLabel.text = "No Favourites added"
        } else if (requiredList == .recentSearchList) {
            titleLabel.text = "Recent Search"
            leftViewLabel.text = "You recently Searched for"
            rightViewButton.setTitle("Clear All", for: .normal)
            emptyViewLabel.text = "No Recent Search"
        }
    }
    
    override func viewDidLayoutSubviews() {
        
        if let view = view as? BackgroundSettingsView {
          view.backgroundImage.frame = self.view.bounds
        }
    }
    
    @IBAction func backButtonClicked(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: true)
    }
    

}

extension WeatherListViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if let weatherListControllerCell = tableView.dequeueReusableCell(withIdentifier: "weatherListControllerCell", for: indexPath) as? WeatherListControllerCell {
            weatherListControllerCell.place.text = "Udupi, Karnataka"
            weatherListControllerCell.temperature.text = "31"
            weatherListControllerCell.weatherImage.image = UIImage(named: "mostlycloudy")
            weatherListControllerCell.temperatureStatus.text = "Mostly Sunny"
            
            return weatherListControllerCell
        }
        
        return WeatherListControllerCell()
    }
    
    
    
}
