//
//  CustomeClassForSearchBar.swift
//  WeatherApp
//
//  Created by Anusree K Babu on 11/06/21.
//

import UIKit

class TransparentSearchBar: UISearchBar {
    
        override init(frame: CGRect) {
            super.init(frame: frame)
            makeTransparentBackground()
        }

        required init?(coder: NSCoder) {
            super.init(coder: coder)
            makeTransparentBackground()
            
        }

        override func layoutSubviews() {
            super.layoutSubviews()
            makeTransparentBackground()
        }

        private func makeTransparentBackground() {
            /*for view in self.subviews {
                view.backgroundColor = UIColor.clear
                for subview in view.subviews {
                    if let imageview = subview as? UIImageView {
                        imageview.image = nil
                    }
                }
            }*/
            self.backgroundImage = UIImage()
        }

    }
