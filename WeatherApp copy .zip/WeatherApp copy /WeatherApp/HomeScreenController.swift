//
//  HomeScreenController.swift
//  WeatherApp
//
//  Created by Anusree K Babu on 09/06/21.
//

import UIKit

class HomeScreenController: UIViewController {
    
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var contentView: UIView!
    @IBOutlet weak var hamburgeView: UIView!
    @IBOutlet weak var unitIndicator: MySegmentedControl!
    @IBOutlet weak var collectionView: UICollectionView!
    
    var subViewHeight: CGFloat = 0.0
    var heightNotSet: Bool = false
    let homeScreenViewModel = HomeScreenViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        hamburgeView.isHidden = true
        let singleTapGestureRecognizer = UITapGestureRecognizer(target: self, action:  #selector (self.singleTap(sender:)))
        scrollView.addGestureRecognizer(singleTapGestureRecognizer)
        collectionView.delegate = self
        collectionView.dataSource = self
        homeScreenViewModel.fetchWeatherDetails() 
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        navigationController?.setNavigationBarHidden(true, animated: false)
    }
    
    override func viewDidLayoutSubviews() {
        
        if let view = view as? BackgroundSettingsView {
          view.backgroundImage.frame = self.view.bounds
        }
        
        if (!heightNotSet) {
           if (UIDevice.current.orientation.isLandscape ) {
               
               subViewHeight = scrollView.frame.width
               print("Device is in landscape mode")
               heightNotSet = true
           } else {
               
               subViewHeight = scrollView.frame.height
               print("Device is in portrait mode")
               heightNotSet = true
           }
        }
       
           let height = NSLayoutConstraint(item: contentView ?? "", attribute: NSLayoutConstraint.Attribute.height, relatedBy: NSLayoutConstraint.Relation.equal, toItem: nil, attribute: NSLayoutConstraint.Attribute.notAnAttribute, multiplier: 1, constant: subViewHeight)
           
            contentView.addConstraint(height)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if let destination = segue.destination as? WeatherListViewController {
            
            if (segue.identifier == "favouriteList") {
                destination.requiredList = .favouriteList
            } else if (segue.identifier == "recentSearchList") {
                destination.requiredList = .recentSearchList
            }
        }
    }
    
    @IBAction func hamburgerButtonClicked(_ sender: Any) {
        
        UIView.animate(withDuration: 0.9) {
            self.hamburgeView.center.x += self.contentView.center.x * 1.33
            self.hamburgeView.isHidden = false
        }
    }
    
    @objc func singleTap(sender: UITapGestureRecognizer){
        
        UIView.animate(withDuration: 0.9) {
            self.hamburgeView.center.x -= self.contentView.center.x * 1.33
            self.hamburgeView.isHidden = true
        }
        self.view.endEditing(true)
    }
    
    @IBAction func homeButtonClicked(_ sender: Any) {
        
        UIView.animate(withDuration: 0.9) {
            self.hamburgeView.center.x -= self.contentView.center.x * 1.33
            self.hamburgeView.isHidden = true
        }
    }
}

extension HomeScreenController: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 5
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "collectionViewCell",for: indexPath) as? CollectionViewCell {
            cell.parameter.text = CustomeClassForParameters().parameterArray()[indexPath.row]
            cell.value.text = "30"
            //cell.parameterImage.image = UIImage(named: "icon_temperature_info")
            cell.parameterImage.image = CustomeClassForParameters().parameterImageArray()[indexPath.row]
            return cell
        }
        return CollectionViewCell()
    }
    
}
