//
//  UIApplication+Extension.swift
//  WeatherApp
//
//  Created by Anusree K Babu on 09/06/21.
//

import UIKit

extension UIApplication {
    
    var statusBarView: UIView? {
        if responds(to: Selector(("statusBar"))) {
            return value(forKey: "statusBar") as? UIView
        }
        return nil
    }
}


