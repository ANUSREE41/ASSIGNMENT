//
//  CustomeClassForParameters.swift
//  WeatherApp
//
//  Created by Anusree K Babu on 11/06/21.
//

import UIKit

class CustomeClassForParameters {
    
    func parameterImageArray() -> [UIImage?] {
        
        return [UIImage(named: "icon_temperature_info"), UIImage(named: "icon_precipitation_info"), UIImage(named: "icon_humidity_info"), UIImage(named: "icon_wind_info"), UIImage(named: "icon_visibility_info")]
    }
    
    func parameterArray() -> [String] {
        
        return ["Min-Max", "Precipitation", "Humidity", "Wind", "Visibility"]
    }
}
