//
//  UIColor+Extention.swift
//  WeatherApp
//
//  Created by Anusree K Babu on 09/06/21.
//

import UIKit

extension UIColor {
    
    static func hamburgerButtomTextColor() -> UIColor {
        return UIColor(red:0.44, green:0.44, blue:0.44, alpha:1)
    }
    
    static func segmentButtomTextColor() -> UIColor {
        return UIColor(red:0.89, green:0.16, blue:0.26, alpha:1)
    }
}
