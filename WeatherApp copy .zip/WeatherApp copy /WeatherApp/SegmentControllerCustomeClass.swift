//
//  SegmentControllerCustomeClass.swift
//  WeatherApp
//
//  Created by Anusree K Babu on 09/06/21.
//

import UIKit

class MySegmentedControl: UISegmentedControl{
    
    override func layoutSubviews() {
            super.layoutSubviews()
        //layer.cornerRadius = 2
    }

    override init(frame: CGRect) {
        
        super.init(frame: frame)
        self.customeSegmentProperties()
    }
    
    required init?(coder: NSCoder) {
        
        super.init(coder: coder)
        self.customeSegmentProperties()
    }
    
    func customeSegmentProperties() {
         
        self.layer.borderColor = UIColor.white.cgColor
        self.layer.borderWidth = 1.5
        self.layer.masksToBounds = true
         
        UISegmentedControl.appearance().setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor.segmentButtomTextColor() as Any], for: .selected)
        UISegmentedControl.appearance().setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor.white as Any], for: .normal)
    }

}
