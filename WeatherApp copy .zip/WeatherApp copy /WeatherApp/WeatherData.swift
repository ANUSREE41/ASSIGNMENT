//
//  WeatherData.swift
//  WeatherApp
//
//  Created by Anusree K Babu on 11/06/21.
//

import Foundation

class WeatherData {
    
    var place: String
    var temperature: Double
    var discription: String
    var minMax: String
    var precipitation: Double
    var humidity: Double
    var wind: Double
    var visibility: Double
    
    init(place: String, temperature: Double, discription: String, minMax: String, precipitation: Double, humidity: Double, wind: Double, visibility: Double) {
        
        self.place = place
        self.temperature = temperature
        self.discription = discription
        self.minMax = minMax
        self.precipitation = precipitation
        self.humidity = humidity
        self.wind = wind
        self.visibility = visibility
    }
}
