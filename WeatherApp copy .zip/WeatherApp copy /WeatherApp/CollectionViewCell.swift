//
//  CollectionViewCell.swift
//  WeatherApp
//
//  Created by Anusree K Babu on 10/06/21.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var parameter: UILabel!
    @IBOutlet weak var value: UILabel!
    @IBOutlet weak var parameterImage: UIImageView!
}
