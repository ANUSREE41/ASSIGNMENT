//
//  NetworkManager.swift
//  WeatherApp
//
//  Created by Anusree K Babu on 11/06/21.
//

import Foundation

class NetworkManager {
    
    func fetchWeatherData() {
        
        guard let weatherURL = URL(string: "https://api.openweathermap.org/data/2.5/weather?q=London&appid=b5a68bdb28c1cc7a5c54039129a6fedd") else {
        return
        }
        
        let session = URLSession.shared
        
        let task = session.dataTask(with: weatherURL) {
        (data, response, error)
        in
        
            if(error != nil){
            print("A")
                print(error.debugDescription)
                return
            }
        
            guard let response = response as? HTTPURLResponse, response.statusCode == 200 else {
                print("B")
                return
            }
        
            guard let newsData = data else {
                print("C")
                return
            }
            
            do {
                let weatherObject = try JSONSerialization.jsonObject(with: newsData, options: [])
                print("fill")
                print(weatherObject)
            } catch {
                print("JSON conversion failed")
            }
                
        }
        
        task.resume()
        print("task resumed")
    }
    
    func parseWeatherData(weatherList: Any)  {
        
        var weatherDetailsArray = [WeatherData]()
        
        guard let weatherList = weatherList as? [String: Any] else {
            return
        }
        
        if let place = weatherList["name"] as? String, let temperture = weatherList["temp"] as? Double, let discription = weatherList["description"] as? String {
            
            print("place")
            print("temperature")
            print("discription")
            
            let currentObject = WeatherData(place: place, temperature: temperture, discription: discription, minMax: "", precipitation: 0.0, humidity: 0.0, wind: 0.0, visibility: 0.0)
            
            if let temp = weatherList["main"] as? [String: Double] {
                if let min = temp["temp_min"], let max = temp["temp_max"], let humidity = temp["humidity"] {
                    currentObject.minMax = "\(min)-\(max)"
                    currentObject.humidity = humidity
                }
            }
            
            if let visibility = weatherList["visibility"] as? Double {
                currentObject.visibility = visibility
            }
            
            if let wind = weatherList["wind"] as? [String: Double] {
                currentObject.wind = wind["speed"] ?? 0.0
            }
        }
    }
}
    
