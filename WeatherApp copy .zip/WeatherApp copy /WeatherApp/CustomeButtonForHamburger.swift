//
//  CustomeButtonForHamburger.swift
//  WeatherApp
//
//  Created by Anusree K Babu on 10/06/21.
//

import UIKit

class CustomeButtonForHamburger: UIButton {
    
    override init(frame: CGRect) {
        
        super.init(frame: frame)
        self.setCoustomButtonProperties()
    }
    
    required init?(coder: NSCoder) {
        
        super.init(coder: coder)
        self.setCoustomButtonProperties()
    }

    func setCoustomButtonProperties() {
        
        self.backgroundColor = UIColor.white
        self.titleLabel?.font = UIFont(name: "Roboto-Regular", size: 14)
        self.setTitleColor(UIColor.hamburgerButtomTextColor(), for: .normal)
    }

}
